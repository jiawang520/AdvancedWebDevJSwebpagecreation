// Use clones of the paragraph Node you create with the lorem string below as the text for the paragraphs. Don't forget to create a text Node first.
//addEventListener with 'onmouseover' ' onmouseleave'
const lorem =
    "Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci in similique expedita, nihil error ducimus saepe quod enim rem laboriosam fuga sed veritatis asperiores.";
// this section puts the links on the top right;
let docBody = document.querySelector("body");
let docDivWrapper = document.createElement("div");
docDivWrapper.setAttribute("class", "wrapper");
let docHeader = document.createElement("header");
let headerNav = document.createElement("nav");
let headerNavA1 = document.createElement("a");
let headerNavA2 = document.createElement("a");
let headerNavA3 = document.createElement("a");
let A1AnchorText = document.createTextNode('MDN');
let A2AnchorText = document.createTextNode('W3 School');
let A3AnchorText = document.createTextNode('WDDTuts');
headerNavA1.appendChild(A1AnchorText);
headerNavA1.setAttribute('href', "https://developer.mozilla.org/en-US/");
headerNavA2.appendChild(A2AnchorText);
headerNavA2.setAttribute('href', "https://www.w3schools.com");
headerNavA3.appendChild(A3AnchorText);
headerNavA3.setAttribute('href', "https://www.wddtuts.com");

headerNav.appendChild(headerNavA1);
headerNav.appendChild(headerNavA2);
headerNav.appendChild(headerNavA3);
docHeader.appendChild(headerNav);
docDivWrapper.appendChild(docHeader);


// big hero section
//big hero section div for big hero
let docMain = document.createElement("main");
let divBigHero = document.createElement("div");
divBigHero.setAttribute("class", "big-hero");
let divBigHeroH1 = document.createElement("h1");
let divBigHeroH1Text = document.createTextNode("Lions Are Awesome");
divBigHeroH1.appendChild(divBigHeroH1Text);
divBigHero.appendChild(divBigHeroH1);
docMain.appendChild(divBigHero);

//div content
let divContent = document.createElement("div");
divContent.setAttribute("class", "content");
let contentP1 = document.createElement("p");
let contentP1Text = document.createTextNode("Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci in similique expedita, nihil error ducimus saepe quod enim rem laboriosam fuga sed veritatis asperiores.");
contentP1.appendChild(contentP1Text);
let contentP2 = document.createElement("p");
let contentP2Text = document.createTextNode("Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci in similique expedita, nihil error ducimus saepe quod enim rem laboriosam fuga sed veritatis asperiores.");
contentP2.appendChild(contentP2Text);
let contentP3 = document.createElement("p");
let contentP3Text = document.createTextNode("Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci in similique expedita, nihil error ducimus saepe quod enim rem laboriosam fuga sed veritatis asperiores.");
contentP3.appendChild(contentP3Text);
divContent.appendChild(contentP1);
divContent.appendChild(contentP2);
divContent.appendChild(contentP3);
docMain.appendChild(divContent);

docDivWrapper.appendChild(docMain);

// Footer section
let docFooter = document.createElement("footer");
let footerNav = document.createElement("nav");
let footerNavA1 = document.createElement("a");
let footerNavA2 = document.createElement("a");
let footerNavA3 = document.createElement("a");
let footerA1AnchorText = document.createTextNode('MDN');
let footerA2AnchorText = document.createTextNode('W3 School');
let footerA3AnchorText = document.createTextNode('WDDTuts');
footerNavA1.appendChild(footerA1AnchorText);
footerNavA1.setAttribute('href', "https://developer.mozilla.org/en-US/");
footerNavA2.appendChild(footerA2AnchorText);
footerNavA2.setAttribute('href', "https://www.w3schools.com");
footerNavA3.appendChild(footerA3AnchorText);
footerNavA3.setAttribute('href', "https://www.wddtuts.com");

footerNav.appendChild(footerNavA1);
footerNav.appendChild(footerNavA2);
footerNav.appendChild(footerNavA3);
docFooter.appendChild(footerNav);
docDivWrapper.appendChild(docFooter);


// appending everything to the body of the html
docBody.appendChild(docDivWrapper);

// CSS styling section
// var boxSize = document.querySelector("*");
// hint.style.boxSizing = "border-box";

var htmlStyle = document.querySelector("html");
htmlStyle.style.fontFamily = "Cambria, Cochin, Georgia, Times, \"Times New Roman\", serif";
htmlStyle.style.fontSize = "20px";
htmlStyle.style.height = "100%";
htmlStyle.style.margin = "0";

var bodyStyle = document.querySelector("body");
bodyStyle.style.height = "100%";
bodyStyle.style.margin = "0";

// var imgStyle = document.querySelector("img");
// // imgStyle.style.height = "auto";
// imgStyle.style.width = "100%";

var headerStyle = document.querySelector("header");
headerStyle.style.background = "#000";
headerStyle.style.display = "flex";
headerStyle.style.justifyContent = "flex-end";

var headerNavStyle = document.querySelector("header > nav");
headerNavStyle.style.display = "flex";

var i;
var headerNavAStyle = document.querySelectorAll("header nav a");
for (i = 0; i < headerNavAStyle.length; i++) {
    headerNavAStyle[i].style.border = "1px solid #000";
    headerNavAStyle[i].style.color = "#fff";
    headerNavAStyle[i].style.padding = "1em";
    headerNavAStyle[i].style.textDecoration = "none";
}
//alternative method for coding the top nav bar below
// headerNavAStyle[0].style.border = "1px solid #000";
// headerNavAStyle[0].style.color = "red";
// headerNavAStyle[0].style.padding = "1em";
// headerNavAStyle[0].style.textDecoration = "none";
// headerNavAStyle[1].style.border = "1px solid #000";
// headerNavAStyle[1].style.color = "red";
// headerNavAStyle[1].style.padding = "1em";
// headerNavAStyle[1].style.textDecoration = "none";
// headerNavAStyle[2].style.border = "1px solid #000";
// headerNavAStyle[2].style.color = "red";
// headerNavAStyle[2].style.padding = "1em";
// headerNavAStyle[2].style.textDecoration = "none";



var bigHeroStyle = document.querySelector(".big-hero");
bigHeroStyle.style.alignItems = "center";
bigHeroStyle.style.backgroundAttachment = "fixed";
bigHeroStyle.style.backgroundImage = "url('../assets/images/Lion_waiting_in_Namibia.jpg')"
bigHeroStyle.style.backgroundSize = "cover";
bigHeroStyle.style.backgroundPosition = "center";
bigHeroStyle.style.display = "flex";
bigHeroStyle.style.justifyContent = "center";
bigHeroStyle.style.minHeight = "100vh";

var bigHeroH1Style = document.querySelector(".big-hero > h1");
bigHeroH1Style.style.fontSize = "calc(0.5em + 5vmin)";

var contentStyle = document.querySelector(".content");
contentStyle.style.margin = "0 auto";
contentStyle.style.maxWidth = "1200px";
contentStyle.style.padding = "0.5em";

var footerStyle = document.querySelector("footer");
footerStyle.style.background = "#000";

var footerNavStyle = document.querySelector("footer > nav");
footerNavStyle.style.display = "flex";

var j;
var footerNavAStyle = document.querySelectorAll("footer nav a");
for (j = 0; j < footerNavAStyle.length; j++) {
    // footerNavAStyle[j].style.border = "1px solid #000";
    footerNavAStyle[j].style.color = "#fff";
    footerNavAStyle[j].style.padding = "1em";
    footerNavAStyle[j].style.textDecoration = "none";
}

// no text directly in Div class wrapper blocking out this css line
// var divWrapperStyle = document.querySelector("#wrapper");
// divWrapperStyle.style.fontSize = "50px";
// divWrapperStyle.stlye.background = "red";

// diagnostics section
// console.dir(headerNavAStyle.style);